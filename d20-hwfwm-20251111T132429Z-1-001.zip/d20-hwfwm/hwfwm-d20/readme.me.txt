# HWFWM System (d20)
Custom Foundry VTT system created by Scott Anderson.
Core Attributes: Power, Speed, Spirit, Recovery.
